import pygame,sys
from random import *
from pygame.locals import *

width = 850
height = 570
x=70
y=200
x_change=0
y_change=0
gravidade=2.5
WHITE = (255,255,255)


def draw_floor():
    screen.blit(floor_surface,(floor_x_pos,500))
    screen.blit(floor_surface,(floor_x_pos + 850,500))

pygame.init()
screen = pygame.display.set_mode((width,height))
clock = pygame.time.Clock()

#projeteis do jogo
disparo = True
xVermelho = 0
yVermelho = 0

#fundo
bg_surface = pygame.image.load('background.png').convert()
bg_surface = pygame.transform.scale2x(bg_surface)


#chão e regulagem da imagem
floor_surface = pygame.image.load('floor.png').convert()
floor_surface = pygame.transform.scale2x(floor_surface)
floor_x_pos = 0


#personagem e regulagem da imagem
duck_surface = pygame.image.load('skate_duck.png')
duck_surface = pygame.transform.scale(duck_surface,(80,80))
duck_rect = duck_surface.get_rect()

def test(x,y):
    screen.blit(duck_surface,(x,y))

while True:
    screen.blit(bg_surface,(0,0))    
    if y > height - 155:
        y = height - 155
    elif y < 0:
        y = 0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        #movimentação do pato, feita pelo jogador
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                y_change=-2.5*gravidade
        elif event.type==pygame.KEYUP:
            if event.key==pygame.K_SPACE:
                y_change=2*gravidade
    #disparos
    if disparo == True:
        xVermelho = randint(10,450)
        yVermelho = 850
        disparo = False
    yVermelho -= 5
    posicaoDisparo = [yVermelho,xVermelho]
    pygame.draw.circle(screen,WHITE, posicaoDisparo, 10)
    if yVermelho <1:
        disparo = True
    #colisao do disparo
    if (y_change + 20 >= yVermelho - 10 and y_change - 20 <= yVermelho + 10) and (x +20  >= xVermelho - 10 and x - 20 <= xVermelho + 20): 
        criar = True
        print('hit')
    y+=y_change
    #chão
    floor_x_pos -=1
    test(x,y)
    draw_floor()
    if floor_x_pos <= -850:
        floor_x_pos = 0
    screen.blit(floor_surface,(floor_x_pos,500))

    pygame.display.update()
    clock.tick(60)